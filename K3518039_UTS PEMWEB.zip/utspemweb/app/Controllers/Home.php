<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		return view('home');
	}
	public function profil()
	{
		return view('profil');
	}
	public function prestasi()
	{
		return view('prestasi');
	}
	public function dosen()
	{
		return view('dosen');
	}
	public function kontak()
	{
		return view('kontak');
	}
	public function portofolio()
	{
		return view('portofolio');
	}
	public function fasilitas()
	{
		return view('fasilitas');
	}
}
