<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Prestasi - PTIK FKIP UNS</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="<?= base_url() ?>/template/assets/img/uns.png" rel="icon">
    <link href="<?= base_url() ?>/template/assets/img/uns.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?= base_url() ?>/template/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/template/assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/template/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/template/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/template/assets/vendor/venobox/venobox.css" rel="stylesheet">
    <link href="<?= base_url() ?>/template/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/template/assets/vendor/aos/aos.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="<?= base_url() ?>/template/assets/css/style.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: Moderna - v2.2.1
  * Template URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top ">
        <div class="container">

            <div class="logo float-left">
                <!-- <h1 class="text-light"><a href="index.html"><span>PTIK FKIP UNS</span></a></h1>-->
                <!-- Uncomment below if you prefer to use an image logo -->
                <a href="index.html"><img src="<?= base_url() ?>/template/assets/img/ptik.png" alt="" class="img-fluid"></a>
            </div>

            <nav class="nav-menu float-right d-none d-lg-block">
                <ul>
                    <li class="active"><a href="<?= base_url() ?>">Home</a></li>
                    <li><a href="<?= base_url() ?>/profil">Profil</a></li>
                    <li><a href="<?= base_url() ?>/prestasi">Prestasi</a></li>
                    <li><a href="<?= base_url() ?>/dosen">Daftar Dosen</a></li>
                    <li><a href="<?= base_url() ?>/portofolio">Portfolio</a></li>
                    <li><a href="<?= base_url() ?>/fasilitas">Fasilitas</a></li>
                    </li>
                    <li><a href="<?= base_url() ?>/kontak">Kontak</a></li>
                </ul>
            </nav><!-- .nav-menu -->

        </div>
    </header><!-- End Header -->

    <main id="main">

        <!-- ======= Our Services Section ======= -->
        <section class="breadcrumbs">
            <div class="container">

                <div class="d-flex justify-content-between align-items-center">
                    <h2>Prestasi Mahasiswa PTIK</h2>
                    <ol>
                        <li><a href="index.html">Home</a></li>
                        <li>Prestasi</li>
                    </ol>
                </div>

            </div>
        </section><!-- End Our Services Section -->

        <!-- ======= Service Details Section ======= -->
        <section class="service-details">
            <div class="container">

                <div class="row">
                    <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                        <div class="card">
                            <div class="card-img">
                                <img src="<?= base_url() ?>/template/assets/img/prestasi1.jpg" alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><a href="#">Mahasiswa PTIK Sabet Medali Perunggu di Jepang</a></h5>
                                <p class="card-text">Mahasiswa Universitas Sebelas Maret (UNS) Surakarta berhasil meraih medali perunggu dalam ajang Advanced Innovation Jam (AI-JAM) Japan 2019 yang digelar di Accenture Innovation Hub Tokyo, Minggu (8/12/2019). Ajang ini merupakan salah satu ajang kompetisi sekaligus...</p>
                                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Baca Selengkapnya</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                        <div class="card">
                            <div class="card-img">
                                <img src="<?= base_url() ?>/template/assets/img/prestasi2.jpg" alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><a href="#">Mahasiswa PTIK UNS Mendapatkan Bronze Medal dan Special Award dari King Abdulaziz University</a></h5>
                                <p class="card-text">Dengan membawa produk inovasi teknologi asistif ke Korea Selatan yang bernama SO-LI Sense : 3D Mapping and Artificial Intelligence Combination Assistive Technology for Blind People, 4 Mahasiswa Pendidikan Teknik Informatika UNS bersama dengan seorang mahasiswa Pendidikan Teknik Mesin yang tergabung…</p>
                                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Baca Selenngkapnya</a></div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                        <div class="card">
                            <div class="card-img">
                                <img src="<?= base_url() ?>/template/assets/img/prestasi3.jpeg" alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><a href="#">HMP PTIK juara Lomba Futsal</a></h5>
                                <p class="card-text">Surakarta, Minggu 22 Oktober 2019. Tim futsal Menara FC dari Program Studi PTIK Universitas Sebelas Maret Surakarta berhasil menjadi juara 2 dalam lomba futsal yang diselenggarakan oleh Himpunan Mahasiswa PPkn Demokratia dengan total hadiah mencapai Rp. 1.500.000,00- . Lomba tersebut… </p>
                                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Baca Selengkapnya</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                        <div class="card">
                            <div class="card-img">
                                <img src="<?= base_url() ?>/template/assets/img/prestasi4.jpeg" alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><a href="#">Mahasiswa UNS meraih juara 3 di LKTI di ITS</a></h5>
                                <p class="card-text">Mahasiswa UNS berhasil meraih juara 3 pada Lomba Karya Tulis Ilmiah Smart Innovation Of Writing Engineering Physics Week 10th Edition yang diselenggarakan oleh Himpunan Mahasiswa Teknik Fisika Institut Teknologi Sepuluh Nopember pada tanggal 31 Agustus – 1 September 2019. Mahasiswa…</p>
                                <div class="read-more"><a href="#"><i class="icofont-arrow-right"></i> Baca Selengkapnya</a></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section><!-- End Service Details Section -->

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">

        <div class="footer-newsletter">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <h4>Our Newsletter</h4>
                        <p>Sampaikan pertanyaan anda lewat email</p>
                    </div>
                    <div class="col-lg-6">
                        <form action="" method="post">
                            <input type="email" name="email"><input type="submit" value="Email">
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3 col-md-6 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-3 col-md-6 footer-links">
                        <h4>Sekolah Mitra</h4>
                        <ul>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">SMKN 1 Sukoharjo</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">SMKN 2 Surakarta</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">SMKN 3 Surakarta</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">SMKN 5 Surakarta</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">SMKN 6 Karanganyar</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-3 col-md-6 footer-contact">
                        <h4>Kontak</h4>
                        <p>
                            Pendidikan Teknik Informatika dan Komputer <br>
                            Kampus V JPTK FKIP UNS Pabelan<br>
                            Jl. Jend. Ahmad Yani 200A Pabelan, Kartasura, Sukoharjo 57100 <br><br>
                            <strong>Telp/Fax:</strong> (0271)648939<br>
                            <strong>Email:</strong> ptik@fkip.uns.ac.id<br>
                        </p>

                    </div>

                    <div class="col-lg-3 col-md-6 footer-info">
                        <h3>Akun Media Sosial</h3>
                        <p>Dapatkan informasi kegiatan PTIK di akun sosial media kami</p>
                        <div class="social-links mt-3">
                            <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                            <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                            <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                            <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="container">
            <div class="copyright">
                &copy; Copyright <strong><span>Moderna</span></strong>. All Rights Reserved
            </div>
            <div class="credits">
                <!-- All the links in the footer should remain intact. -->
                <!-- You can delete the links only if you purchased the pro version. -->
                <!-- Licensing information: https://bootstrapmade.com/license/ -->
                <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/ -->
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
            </div>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

    <!-- Vendor JS Files -->
    <script src="<?= base_url() ?>/template/assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/php-email-form/validate.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/venobox/venobox.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/counterup/counterup.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="<?= base_url() ?>/template/assets/vendor/aos/aos.js"></script>

    <!-- Template Main JS File -->
    <script src="<?= base_url() ?>/template/assets/js/main.js"></script>

</body>

</html>