<body>
    <div class="preloader">
        <img src="<?= base_url("") ?>/assets/img/loader.gif" alt="Preloader image">
    </div>
    <nav class="navbar">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="<?= base_url("") ?>/assets/img/ptik.png" data-active-url="img/ptik.png" alt=""></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right main-nav">
                    <li><a href="#intro">HOME</a></li>
                    <li><a href="#services">PROFIL</a></li>
                    <li><a href="#team">GALERI</a></li>
                    <li><a href="#pricing">KONTAK</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <header id="intro">
        <div class="container">
            <div class="table">
                <div class="header-text">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h3 class="light white">Welcome To</h3>
                            <h1 class="white typed">PTIK FKIP UNS</h1>
                            <span class="typed-cursor">|</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section id="services" class="section section-padded">
        <div class="container">
            <div class="row text-center title">
                <h2>PROFIL</h2>
                <h4 class="light muted">Program studi Pendidikan Teknologi Informatika dan Komputer (PTIK) direncanakan bernaung dalam pengelolaan jurusan Pendidikan Teknik dan Kejuruan (PTK). Penempatan ini merevisi pernyataan kami sebelumnya, dimana program studi PTIK bernanung di bawah jurusan P.MIPA. PTIK merupakan program studi yang akan menghasilkan lulusan yang diutamakan akan mengajar dalam program vokasi/kejuruan. Sehingga, akan lebih baik jika PTIK bernanung di bawah jurusan PTK yang membawahi program-program vokasi seperti Pendidikan Teknik Bangunan, dan Pendidikan Teknik Mesin. Untuk memenuhi kebutuhan dosen bidang teknologi informasi yang belum dapat dipenuhi oleh jurusan PTK, PTIK akan melakukan resource sharing dengan prodi matematika.</h4>
            </div>
            <div class="row services">
                <div class="col-md-4">
                    <div class="service">
                        <div class="icon-holder">
                            <img src="<?= base_url("") ?>/assets/img/icons/heart-blue.png" alt="" class="icon">
                        </div>
                        <h4 class="heading">Tujuan</h4>
                        <p class="description">Menghasilkan lulusan yang beriman dan bertaqwa kepada Tuhan Yang Maha Esa berkepribadian luhur, cerdas dan terampil yang siap menjadi tenaga pendidik </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service">
                        <div class="icon-holder">
                            <img src="<?= base_url("") ?>/assets/img/icons/guru-blue.png" alt="" class="icon">
                        </div>
                        <h4 class="heading">Visi</h4>
                        <p class="description">“Menjadi pusat pendidikan, penelitian dan pelatihan yang unggul dan inovatif di tingkat internasional bidang pendidikan kejuruan teknik informatika dan komputer </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service">
                        <div class="icon-holder">
                            <img src="<?= base_url("") ?>/assets/img/icons/weight-blue.png" alt="" class="icon">
                        </div>
                        <h4 class="heading">Misi</h4>
                        <p class="description">Menyelenggarakan pendidikan, pelatihan dan bimbingan secara efektif untuk menghasilkan tenaga pendidik yang unggul dan inovatif, berdaya saing tinggi,</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="cut cut-bottom"></div>
    </section>
    <section id="team" class="section gray-bg">
        <div class="container">
            <div class="row title text-center">
                <h2 class="margin-top">INFO</h2>

            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="team text-center">
                        <div class="cover" style="background:url('img/team/team-cover1.jpg'); background-size:cover;">
                            <div class="overlay text-center">
                                <h3 class="white">Akreditasi Program Studi</h3>

                            </div>
                        </div>
                        <img src="<?= base_url("") ?>/assets/img/team/team3.jpg" alt="Team Image" class="avatar">
                        <div class="title">
                            <h4>Ben Adamson</h4>
                            <h5 class="muted regular">Fitness Instructor</h5>
                        </div>
                        <button data-toggle="modal" data-target="#modal1" class="btn btn-blue-fill">Sign Up Now</button>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="team text-center">
                        <div class="cover" style="background:url('img/team/team-cover2.jpg'); background-size:cover;">
                            <div class="overlay text-center">
                                <h3 class="white">$69.00</h3>
                                <h5 class="light light-white">1 - 5 sessions / month</h5>
                            </div>
                        </div>
                        <img src="<?= base_url("") ?>/assets/img/team/team1.jpg" alt="Team Image" class="avatar">
                        <div class="title">
                            <h4>Eva Williams</h4>
                            <h5 class="muted regular">Personal Trainer</h5>
                        </div>
                        <a href="#" data-toggle="modal" data-target="#modal1" class="btn btn-blue-fill ripple">Sign Up Now</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="team text-center">
                        <div class="cover" style="background:url('img/team/team-cover3.jpg'); background-size:cover;">
                            <div class="overlay text-center">
                                <h3 class="white">$69.00</h3>
                                <h5 class="light light-white">1 - 5 sessions / month</h5>
                            </div>
                        </div>
                        <img src="<?= base_url("") ?>/assets/img/team/team2.jpg" alt="Team Image" class="avatar">
                        <div class="title">
                            <h4>John Phillips</h4>
                            <h5 class="muted regular">Personal Trainer</h5>
                        </div>
                        <a href="#" data-toggle="modal" data-target="#modal1" class="btn btn-blue-fill ripple">Sign Up Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="pricing" class="section">
        <div class="container">
            <div class="row title text-center">
                <h2 class="margin-top white">Pricing</h2>
                <h4 class="light white">Choose your favorite pricing plan and sign up today!</h4>
            </div>
            <div class="row no-margin">
                <div class="col-md-7 no-padding col-md-offset-5 pricings text-center">
                    <div class="pricing">
                        <div class="box-main active" data-img="img/pricing1.jpg">
                            <h4 class="white">Yoga Pilates</h4>
                            <h4 class="white regular light">$850.00 <span class="small-font">/ year</span></h4>
                            <a href="#" data-toggle="modal" data-target="#modal1" class="btn btn-white-fill">Sign Up Now</a>
                            <i class="info-icon icon_question"></i>
                        </div>
                        <div class="box-second active">
                            <ul class="white-list text-left">
                                <li>One Personal Trainer</li>
                                <li>Big gym space for training</li>
                                <li>Free tools &amp; props</li>
                                <li>Free locker</li>
                                <li>Free before / after shower</li>
                            </ul>
                        </div>
                    </div>
                    <div class="pricing">
                        <div class="box-main" data-img="img/pricing2.jpg">
                            <h4 class="white">Cardio Training</h4>
                            <h4 class="white regular light">$100.00 <span class="small-font">/ year</span></h4>
                            <a href="#" data-toggle="modal" data-target="#modal1" class="btn btn-white-fill">Sign Up Now</a>
                            <i class="info-icon icon_question"></i>
                        </div>
                        <div class="box-second">
                            <ul class="white-list text-left">
                                <li>One Personal Trainer</li>
                                <li>Big gym space for training</li>
                                <li>Free tools &amp; props</li>
                                <li>Free locker</li>
                                <li>Free before / after shower</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section section-padded blue-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="owl-twitter owl-carousel">
                        <div class="item text-center">
                            <i class="icon fa fa-twitter"></i>
                            <h4 class="white light">To enjoy the glow of good health, you must exercise.</h4>
                            <h4 class="light-white light">#health #training #exercise</h4>
                        </div>
                        <div class="item text-center">
                            <i class="icon fa fa-twitter"></i>
                            <h4 class="white light">To enjoy the glow of good health, you must exercise.</h4>
                            <h4 class="light-white light">#health #training #exercise</h4>
                        </div>
                        <div class="item text-center">
                            <i class="icon fa fa-twitter"></i>
                            <h4 class="white light">To enjoy the glow of good health, you must exercise.</h4>
                            <h4 class="light-white light">#health #training #exercise</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content modal-popup">
                <a href="#" class="close-link"><i class="icon_close_alt2"></i></a>
                <h3 class="white">Sign Up</h3>
                <form action="" class="popup-form">
                    <input type="text" class="form-control form-white" placeholder="Full Name">
                    <input type="text" class="form-control form-white" placeholder="Email Address">
                    <div class="dropdown">
                        <button id="dLabel" class="form-control form-white dropdown" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Pricing Plan
                        </button>
                        <ul class="dropdown-menu animated fadeIn" role="menu" aria-labelledby="dLabel">
                            <li class="animated lightSpeedIn"><a href="#">1 month membership ($150)</a></li>
                            <li class="animated lightSpeedIn"><a href="#">3 month membership ($350)</a></li>
                            <li class="animated lightSpeedIn"><a href="#">1 year membership ($1000)</a></li>
                            <li class="animated lightSpeedIn"><a href="#">Free trial class</a></li>
                        </ul>
                    </div>
                    <div class="checkbox-holder text-left">
                        <div class="checkbox">
                            <input type="checkbox" value="None" id="squaredOne" name="check" />
                            <label for="squaredOne"><span>I Agree to the <strong>Terms &amp; Conditions</strong></span></label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-submit">Submit</button>
                </form>
            </div>
        </div>
    </div>